import NavBar from "../components/NavBar";
import HeroSection from "../components/HeroSection";
import AchievementsSection from "../components/AchievementsSection";
import LichessSection from "../components/LichessSection";
import MentorSection from "../components/MentorSection";
import StudentCasesSection from "../components/StudentCasesSection";
import DragonRepertoireSection from "../components/DragonRepertoireSection";
import AboutSection from "../components/AboutSection";
import QASection from "../components/QASection";
import PricingSection from "../components/PricingSection";
import FooterSection from "../components/FooterSection";

export default function Home() {
  return (
    <div style={{ background: '#050505', color: '#F5F5F5', fontFamily: "'Inter', sans-serif" }} className="min-h-screen">
      <NavBar />
      <HeroSection />
      <AchievementsSection />
      <LichessSection />
      <MentorSection />
      <StudentCasesSection />
      <DragonRepertoireSection />
      <AboutSection />
      <QASection />
      <PricingSection />
      <FooterSection />
    </div>
  );
}