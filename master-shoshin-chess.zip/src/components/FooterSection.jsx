export default function FooterSection() {
  return (
    <footer className="py-12 border-t" style={{ background: '#050505', borderColor: 'rgba(227,27,35,0.15)' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <p className="font-black tracking-widest text-lg" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>SHOSHIN</p>
          <p className="text-xs mt-1" style={{ color: '#555' }}>FIDE Master · Шахматный тренер · Санкт-Петербург</p>
        </div>
        <div className="flex gap-6 text-xs" style={{ color: '#555' }}>
          <a href="https://t.me/SHOSHIN_KIRILL" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Telegram</a>
          <a href="tel:+79115076060" className="hover:text-white transition-colors">+7 911 507 6060</a>
          <a href="https://lichess.org/@/Kirill_Shoshin" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Lichess</a>
        </div>
        <p className="text-xs" style={{ color: '#333' }}>© 2024 Кирилл Шошин</p>
      </div>
    </footer>
  );
}