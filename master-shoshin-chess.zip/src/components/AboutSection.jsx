export default function AboutSection() {
  const hobbies = [
    { icon: "🏋️", title: "КМС по жиму лёжа", desc: "Кандидат в Мастера Спорта. Дисциплина в тренажёрном зале — отражение дисциплины за доской." },
    { icon: "💪", title: "КМС по калистенике", desc: "Подтягивания с дополнительным весом. Осваиваю подтягивания на одной руке." },
    { icon: "🎓", title: "Топ-1% студентов СПбГУ", desc: "Факультет «Менеджмент» — лучшая бизнес-школа России. Направлен учиться по обмену в лучшую бизнес-школу Латинской Америки FGV EAESP (Сан-Паулу, Бразилия).", link: "https://drive.google.com/file/d/1hqziBmos5bADMb2YiDkR1SBiZSzCtaSI/view?usp=drive_link" },
  ];

  return (
    <section className="py-32" style={{ background: '#050505' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="h-px w-12" style={{ background: '#E31B23' }} />
              <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>BEYOND THE BOARD</span>
            </div>
            <h2 className="font-black mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
              Превосходство —<br />
              <span style={{ color: '#E31B23' }}>это образ жизни</span>
            </h2>
            <p className="text-base leading-relaxed mb-8" style={{ color: '#888' }}>
              15 лет в шахматах. 6 лет преподавания. 85+ учеников. 
              Но шахматы — лишь одна грань. Я верю: дисциплина, которая 
              делает тебя мастером в одном, неизбежно переносится во всё остальное.
            </p>

            <div className="space-y-4">
              {hobbies.map((h, i) => (
                <div key={i} className="flex gap-4 p-4" style={{ background: 'rgba(227,27,35,0.04)', border: '1px solid rgba(227,27,35,0.15)' }}>
                  <span className="text-2xl flex-shrink-0">{h.icon}</span>
                  <div>
                    <p className="font-bold text-sm mb-1" style={{ color: '#F5F5F5' }}>{h.title}</p>
                    <p className="text-xs leading-relaxed" style={{ color: '#888' }}>{h.desc}</p>
                    {h.link && (
                      <a
                        href={h.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold mt-1 inline-flex items-center gap-1"
                        style={{ color: '#E31B23' }}
                      >
                        СМОТРЕТЬ СЕРТИФИКАТ
                        <svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M7 17L17 7M17 7H7M17 7v10" /></svg>
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Photo */}
          <div className="relative">
            <div className="absolute -inset-4 opacity-20" style={{ background: 'radial-gradient(circle, #E31B23, transparent 70%)' }} />
            <div className="relative" style={{ border: '1px solid rgba(227,27,35,0.3)' }}>
              <img
                src="https://media.base44.com/images/public/user_69ce39ac76ac3639b76873f2/7068b312b_Presentation.jpg"
                alt="Кирилл Шошин — выступление"
                className="w-full"
                style={{ filter: 'contrast(1.05)' }}
              />
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.6) 0%, transparent 50%)' }} />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <p className="text-xs tracking-widest font-bold mb-1" style={{ color: '#E31B23', letterSpacing: '0.2em' }}>ИНТЕЛЛЕКТУАЛЬНЫЙ АТЛЕТ</p>
                <p className="text-sm" style={{ color: '#F5F5F5' }}>Выступление на академической конференции СПбГУ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}