export default function Footer() {
  return (
    <footer className="py-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="font-display text-lg text-ivory tracking-wider">SHOSHIN</div>
          <div className="flex items-center gap-6">
            <a
              href="https://t.me/SHOSHIN_KIRILL"
              target="_blank"
              rel="noopener noreferrer"
              className="text-steel text-xs tracking-wider uppercase hover:text-crimson transition-colors"
            >
              Telegram
            </a>
            <a
              href="https://lichess.org/@/Kirill_Shoshin"
              target="_blank"
              rel="noopener noreferrer"
              className="text-steel text-xs tracking-wider uppercase hover:text-crimson transition-colors"
            >
              Lichess
            </a>
            <a
              href="https://www.avito.ru/brands/50780bc3662f14f172f49050637bf3a4/all/predlozheniya_uslug?src=search_seller_info&iid=7951772649&sellerId=b4db6a7fd1f96d90bdf7488ec92269ed"
              target="_blank"
              rel="noopener noreferrer"
              className="text-steel text-xs tracking-wider uppercase hover:text-crimson transition-colors"
            >
              Отзывы
            </a>
          </div>
          <div className="text-steel/50 text-xs">© {new Date().getFullYear()} Кирилл Шошин</div>
        </div>
      </div>
    </footer>
  );
}