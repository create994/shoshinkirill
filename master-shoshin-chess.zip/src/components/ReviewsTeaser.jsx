import AnimatedSection from './AnimatedSection';
import { ExternalLink } from 'lucide-react';

export default function ReviewsTeaser() {
  return (
    <section className="relative py-20 noise-bg">
      <div className="max-w-3xl mx-auto px-6 lg:px-10 text-center">
        <AnimatedSection>
          <div className="p-8 border border-white/5 bg-white/[0.02]">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-8 h-px bg-crimson" />
              <span className="text-crimson text-xs tracking-[0.4em] uppercase">Отзывы</span>
              <div className="w-8 h-px bg-crimson" />
            </div>
            <p className="text-ivory text-lg md:text-xl font-display mb-6">
              Слово — ученикам
            </p>
            <p className="text-steel text-sm leading-relaxed mb-6">
              Реальные отзывы людей, которые прошли путь трансформации вместе со мной. Без редактуры и приукрашивания.
            </p>
            <a
              href="https://www.avito.ru/brands/50780bc3662f14f172f49050637bf3a4/all/predlozheniya_uslug?src=search_seller_info&iid=7951772649&sellerId=b4db6a7fd1f96d90bdf7488ec92269ed"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 border border-crimson/50 bg-crimson/10 hover:bg-crimson/20 transition-all text-ivory text-sm tracking-wider uppercase"
            >
              <ExternalLink size={14} />
              Читать отзывы
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}