export default function DragonRepertoireSection() {
  return (
    <section className="py-32 relative overflow-hidden" style={{ background: '#060606' }}>
      {/* Dragon background glow */}
      <div className="absolute inset-0 opacity-20" style={{
        background: 'radial-gradient(ellipse at 70% 50%, rgba(227,27,35,0.4), transparent 65%)'
      }} />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — text */}
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="h-px w-12" style={{ background: '#E31B23' }} />
              <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>БЕСПЛАТНЫЙ МАТЕРИАЛ</span>
            </div>

            <h2 className="font-black mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
              Попробуйте мой<br />
              <span style={{ color: '#E31B23' }}>дебютный репертуар</span>
            </h2>

            <p className="text-base leading-relaxed mb-4" style={{ color: '#888' }}>
              Прежде чем принять решение — оцените качество материала бесплатно. 
              Это фрагмент моего личного дебютного репертуара, который уже будет фантастически полезен.
            </p>

            <div className="p-6 mb-8" style={{ background: 'rgba(227,27,35,0.06)', border: '1px solid rgba(227,27,35,0.3)' }}>
              <p className="text-xs tracking-widest font-bold mb-3" style={{ color: '#E31B23', letterSpacing: '0.25em' }}>РАННИЙ ДРАКОН</p>
              <p className="text-base leading-relaxed mb-4" style={{ color: '#F5F5F5' }}>
                Сокрушительный дебют, который заставляет соперника защищаться с первых ходов. 
                Развивает чувство инициативы и атаки. Принёс множество ярчайших побед.
              </p>
              <p className="text-sm leading-relaxed" style={{ color: '#888' }}>
                Все варианты записаны и структурированы на Lichess — 
                интерактивное изучение с доской прямо в браузере.
              </p>
            </div>

            <a
              href="https://lichess.org/study/ULSNo9DX/u9gvtKU0"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-8 py-4 font-bold tracking-widest text-sm transition-all"
              style={{ background: '#E31B23', color: '#fff', letterSpacing: '0.1em', minHeight: '56px' }}
              onMouseEnter={e => e.currentTarget.style.background = '#c01419'}
              onMouseLeave={e => e.currentTarget.style.background = '#E31B23'}
            >
              <span>♟</span>
              ИЗУЧИТЬ БЕСПЛАТНО НА LICHESS
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M7 17L17 7M17 7H7M17 7v10" />
              </svg>
            </a>
          </div>

          {/* Right — dragon image */}
          <div className="relative flex justify-center">
            <div className="absolute inset-0 -m-8 opacity-30" style={{ background: 'radial-gradient(circle, #E31B23, transparent 70%)' }} />
            <div className="relative" style={{ border: '1px solid rgba(227,27,35,0.4)' }}>
              <img
                src="https://media.base44.com/images/public/69ce3a1749f1477335791fdd/6390e929c_generated_image.png"
                alt="Дракон — Ранний Дракон дебют"
                className="w-full max-w-md"
                style={{ filter: 'contrast(1.1) saturate(1.1)' }}
              />
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, transparent 60%, rgba(6,6,6,0.8))' }} />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-center">
                <p className="text-xs tracking-widest font-black" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>РАННИЙ ДРАКОН</p>
                <p className="text-xs mt-1" style={{ color: '#888' }}>из личного репертуара FIDE Мастера Шошина</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}