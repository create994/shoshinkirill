import { useState, useEffect } from "react";

export default function NavBar() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      const doc = document.documentElement;
      const scrollTop = window.scrollY;
      const scrollHeight = doc.scrollHeight - doc.clientHeight;
      setProgress(scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      {/* Progress bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-0.5" style={{ background: '#111' }}>
        <div
          className="h-full transition-all duration-100"
          style={{ width: `${progress}%`, background: '#E31B23' }}
        />
      </div>

      <nav
        className="fixed top-0.5 left-0 right-0 z-40 transition-all duration-300"
        style={{ background: scrolled ? 'rgba(5,5,5,0.95)' : 'transparent', backdropFilter: scrolled ? 'blur(10px)' : 'none', borderBottom: scrolled ? '1px solid rgba(227,27,35,0.2)' : 'none' }}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between h-16">
          <span
            className="font-bold tracking-widest text-sm cursor-pointer"
            style={{ color: '#E31B23', letterSpacing: '0.3em' }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            SHOSHIN
          </span>
          <div className="hidden md:flex gap-8 text-xs tracking-widest" style={{ color: '#888' }}>
            {[['achievements', 'ДОСТИЖЕНИЯ'], ['lichess', 'РЕЙТИНГ'], ['mentor', 'НАСТАВНИК'], ['cases', 'УЧЕНИКИ'], ['pricing', 'ИНВЕСТИЦИЯ']].map(([id, label]) => (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                className="hover:text-white transition-colors"
                style={{ letterSpacing: '0.15em' }}
              >
                {label}
              </button>
            ))}
          </div>
          <a
            href="https://t.me/SHOSHIN_KIRILL"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs tracking-widest px-4 py-2 border transition-all hover:text-black font-medium"
            style={{ borderColor: '#E31B23', color: '#E31B23', letterSpacing: '0.1em' }}
            onMouseEnter={e => { e.currentTarget.style.background = '#E31B23'; e.currentTarget.style.color = '#fff'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#E31B23'; }}
          >
            ЗАПИСАТЬСЯ
          </a>
        </div>
      </nav>
    </>
  );
}