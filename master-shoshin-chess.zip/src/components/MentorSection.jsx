import { useState } from "react";

export default function MentorSection() {
  const [videoOpen, setVideoOpen] = useState(false);

  return (
    <section id="mentor" className="py-32" style={{ background: '#050505' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ШКОЛА МАСТЕРСТВА</span>
          </div>
          <h2 className="font-black" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', letterSpacing: '-0.02em' }}>
            <span style={{ color: '#F5F5F5' }}>Наставник </span><span style={{ color: '#E31B23' }}>мирового</span><br />
            <span style={{ color: '#F5F5F5' }}>уровня</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-stretch mb-16">
          {/* Left column */}
          <div className="flex flex-col">
            <a href="https://ru.wikipedia.org/wiki/Шерешевский,_Михаил_Израилевич" target="_blank" rel="noopener noreferrer">
              <div className="relative overflow-hidden group" style={{ border: '1px solid rgba(227,27,35,0.3)' }}>
                <img
                  src="https://media.base44.com/images/public/69ce3a1749f1477335791fdd/a86ea67af_.png"
                  alt="Михаил Шерешевский"
                  className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ objectPosition: 'center top' }}
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.9) 20%, transparent 60%)' }} />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-xs tracking-widest mb-1" style={{ color: '#E31B23', letterSpacing: '0.2em' }}>МОЙ НАСТАВНИК</p>
                  <h3 className="text-2xl font-black" style={{ color: '#F5F5F5' }}>Михаил Шерешевский</h3>
                  <p className="text-sm mt-1" style={{ color: '#888' }}>Заслуженный тренер · Автор легендарных бестселлеров</p>
                </div>
              </div>
            </a>

            {/* Video button — flex-1 stretches to match right column height */}
            <button
              onClick={() => setVideoOpen(true)}
              className="mt-4 w-full flex-1 transition-all relative overflow-hidden"
              style={{ border: '1px solid rgba(227,27,35,0.3)', minHeight: '120px' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#E31B23'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(227,27,35,0.3)'}
            >
              {/* Background photo — full brightness */}
              <div className="absolute inset-0" style={{
                backgroundImage: 'url(https://media.base44.com/images/public/69ce3a1749f1477335791fdd/e3da1506d_.png)',
                backgroundSize: 'cover',
                backgroundPosition: 'center center',
              }} />
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.85) 30%, rgba(5,5,5,0.2) 100%)' }} />
              {/* Text pinned to bottom */}
              <div className="absolute bottom-0 left-0 right-0 z-10 flex items-center gap-4 p-5">
                <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#E31B23' }}>
                  <svg width="16" height="16" fill="white" viewBox="0 0 24 24"><path d="M5 3l14 9-14 9V3z"/></svg>
                </div>
                <div className="text-left">
                  <p className="text-base font-bold" style={{ color: '#F5F5F5' }}>Шерешевский о работе Кирилла Шошина</p>
                  <p className="text-sm mt-1" style={{ color: '#ccc' }}>Интервью у филантропа и бизнесмена — Ильи Левитова · Rutube</p>
                </div>
              </div>
            </button>
          </div>

          {/* Text */}
          <div className="flex flex-col">
            <blockquote className="mb-8 pl-6" style={{ borderLeft: '3px solid #E31B23' }}>
              <p className="text-lg leading-relaxed italic" style={{ color: '#F5F5F5' }}>
                «Заслуги Михаила Израилевича Шерешевского в мире шахмат отмечают даже чемпионы мира. 
                Владимир Крамник — 14-й чемпион мира — рекомендует его книги как образец шахматного мышления.
                Магнус Карлсен, сильнейший шахматист в истории, лично отметил высочайшее качество его трудов.»
              </p>
            </blockquote>

            <p className="text-base leading-relaxed mb-6" style={{ color: '#888' }}>
              Ян Непомнящий, Даниил Дубов и Евгений Томашевский открыто признают 
              революционность методологии Шерешевского. Я имею привилегию работать 
              напрямую с этим человеком — и именно это определяет уровень знаний, 
              которые я передаю своим ученикам.
            </p>

            <p className="text-base leading-relaxed mb-8" style={{ color: '#888' }}>
              Во время интервью у ведущего шахматного мецената и бизнесмена России{' '}
              <a
                href="https://cyclowiki.org/wiki/Илья_Владиславович_Левитов"
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: '#F5F5F5', textDecoration: 'underline', textDecorationColor: 'rgba(227,27,35,0.6)' }}
              >
                Ильи Левитова
              </a>
              , Михаил Израилевич специально упомянул революционный анализ ладейного эндшпиля, 
              проделанный мной. Анализ был выполнен в качестве подготовки материала к занятиям со моими учениками.
            </p>

            {/* Sirius */}
            <div className="mt-auto p-5" style={{ background: 'rgba(227,27,35,0.05)', border: '1px solid rgba(227,27,35,0.2)' }}>
              <p className="text-xs tracking-widest mb-2 font-bold" style={{ color: '#E31B23', letterSpacing: '0.2em' }}>ТАКЖЕ РАБОТАЛ С</p>
              <p className="text-sm leading-relaxed" style={{ color: '#F5F5F5' }}>
                <strong>Сергей Иванов, Константин Сакаев, Владимир Беликов</strong> — 
                ведущие тренеры страны. Смены в ОЦ «Сириус» (Сочи) для талантливейших 
                юниоров России.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Video Modal */}
      {videoOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.95)' }}
          onClick={() => setVideoOpen(false)}
        >
          <div
            className="relative w-full max-w-3xl"
            onClick={e => e.stopPropagation()}
            style={{ border: '1px solid rgba(227,27,35,0.4)' }}
          >
            <button
              onClick={() => setVideoOpen(false)}
              className="absolute -top-10 right-0 text-sm tracking-widest"
              style={{ color: '#888' }}
            >
              ЗАКРЫТЬ ×
            </button>
            <div className="aspect-video">
              <iframe
                src="https://rutube.ru/play/embed/4758b7d6d7e05418accae82302cd85c3"
                className="w-full h-full"
                allowFullScreen
                title="Шерешевский об анализе Кирилла Шошина"
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
}