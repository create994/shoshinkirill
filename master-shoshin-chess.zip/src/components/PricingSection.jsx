export default function PricingSection() {
  const packages = [
    {
      sessions: 8,
      price: "16 990",
      perSession: "2 124",
      savings: "Экономия 970 ₽",
      highlight: false,
    },
    {
      sessions: 10,
      price: "20 490",
      perSession: "2 049",
      savings: "Экономия 1 960 ₽",
      highlight: true,
      badge: "ПОПУЛЯРНЫЙ",
    },
    {
      sessions: 12,
      price: "23 990",
      perSession: "1 999",
      savings: "Экономия 2 950 ₽",
      highlight: false,
    },
  ];

  return (
    <section id="pricing" className="py-32" style={{ background: '#050505' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ИНВЕСТИЦИЯ В МАСТЕРСТВО</span>
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
          </div>
          <h2 className="font-black mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
            Ценообразование, основанное на <span style={{ color: '#E31B23' }}>качестве</span>
          </h2>
          <p className="max-w-2xl mx-auto text-base leading-relaxed" style={{ color: '#888' }}>
            Премиальные уроки Игры Королей для тех, кто бескомпромиссно ориентирован на самое лучшее качество обучения
          </p>
        </div>

        {/* Single sessions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 max-w-2xl mx-auto">
          {[
            { label: "Пробное занятие", price: "2 150 ₽", sub: "1 час · первое знакомство" },
            { label: "Регулярное занятие", price: "2 450 ₽", sub: "1 час · от 2-го занятия" },
          ].map((s, i) => (
            <div key={i} className="p-6" style={{ background: '#0a0a0a', border: '1px solid rgba(227,27,35,0.2)' }}>
              <p className="text-xs tracking-widest mb-2 font-bold" style={{ color: '#888', letterSpacing: '0.15em' }}>{s.label.toUpperCase()}</p>
              <p className="text-3xl font-black mb-1" style={{ color: '#F5F5F5' }}>{s.price}</p>
              <p className="text-xs" style={{ color: '#888' }}>{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Packages */}
        <div className="mb-4">
          <p className="text-center text-xs tracking-widest font-bold mb-6" style={{ color: '#E31B23', letterSpacing: '0.25em' }}>ПАКЕТЫ ЗАНЯТИЙ — ВЫГОДНЕЕ</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {packages.map((pkg, i) => (
              <div
                key={i}
                className="relative overflow-hidden transition-all duration-300"
                style={{
                  background: pkg.highlight ? 'rgba(227,27,35,0.08)' : '#0a0a0a',
                  border: pkg.highlight ? '1px solid #E31B23' : '1px solid rgba(227,27,35,0.2)',
                  padding: '2rem',
                }}
                onMouseEnter={e => { if (!pkg.highlight) e.currentTarget.style.borderColor = '#E31B23'; }}
                onMouseLeave={e => { if (!pkg.highlight) e.currentTarget.style.borderColor = 'rgba(227,27,35,0.2)'; }}
              >
                {pkg.badge && (
                  <div className="absolute top-0 right-0 px-3 py-1 text-xs font-black tracking-widest" style={{ background: '#E31B23', color: '#fff', letterSpacing: '0.1em' }}>
                    {pkg.badge}
                  </div>
                )}
                <p className="text-xs tracking-widest mb-4 font-bold" style={{ color: '#888', letterSpacing: '0.2em' }}>{pkg.sessions} ЗАНЯТИЙ</p>
                <p className="text-4xl font-black mb-2" style={{ color: '#F5F5F5' }}>{pkg.price} ₽</p>
                <p className="text-sm mb-1" style={{ color: '#888' }}>{pkg.perSession} ₽ за занятие</p>
                <p className="text-xs font-bold" style={{ color: '#E31B23' }}>{pkg.savings}</p>
                <div className="mt-6 pt-6" style={{ borderTop: '1px solid rgba(227,27,35,0.2)' }}>
                  <a
                    href="https://t.me/SHOSHIN_KIRILL"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full text-center py-3 text-xs font-bold tracking-widest transition-all"
                    style={{
                      background: pkg.highlight ? '#E31B23' : 'transparent',
                      color: pkg.highlight ? '#fff' : '#E31B23',
                      border: pkg.highlight ? 'none' : '1px solid #E31B23',
                      letterSpacing: '0.1em',
                    }}
                    onMouseEnter={e => { if (!pkg.highlight) { e.currentTarget.style.background = 'rgba(227,27,35,0.1)'; } else { e.currentTarget.style.background = '#c01419'; } }}
                    onMouseLeave={e => { if (!pkg.highlight) { e.currentTarget.style.background = 'transparent'; } else { e.currentTarget.style.background = '#E31B23'; } }}
                  >
                    ВЫБРАТЬ ПАКЕТ
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-center text-xs italic" style={{ color: '#555' }}>
          * Такое ценообразование установлено намеренно — чтобы выделить тех, кто готов к системной, долгосрочной работе.
        </p>

        {/* Final CTA */}
        <div className="mt-20 relative overflow-hidden" style={{ background: 'rgba(227,27,35,0.05)', border: '1px solid rgba(227,27,35,0.3)' }}>
          <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle at center, #E31B23, transparent 70%)' }} />
          <div className="relative z-10 flex flex-col lg:flex-row items-stretch">
            <div className="lg:w-72 flex-shrink-0 overflow-hidden">
              <img
                src="https://media.base44.com/images/public/69ce3a1749f1477335791fdd/5fea0b6a0_.jpg"
                alt="Кирилл Шошин"
                className="w-full h-full object-cover"
                style={{ minHeight: '260px', objectPosition: 'center top' }}
              />
            </div>
            <div className="flex-1 p-12 text-center flex flex-col items-center justify-center">
              <p className="text-xs tracking-widest mb-4 font-bold" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>НАЧНЁМ ПРЯМО СЕЙЧАС</p>
              <h3 className="font-black text-3xl md:text-4xl mb-4" style={{ color: '#F5F5F5' }}>Первый ход — Ваш</h3>
              <p className="mb-8 text-base" style={{ color: '#888' }}>Telegram — самый быстрый способ договориться об удобном времени</p>
              <div className="flex flex-wrap gap-4 justify-center">
                <a
                  href="https://t.me/SHOSHIN_KIRILL"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-10 py-4 font-bold tracking-widest text-sm transition-all"
                  style={{ background: '#E31B23', color: '#fff', letterSpacing: '0.1em', minHeight: '56px', display: 'inline-flex', alignItems: 'center' }}
                  onMouseEnter={e => e.currentTarget.style.background = '#c01419'}
                  onMouseLeave={e => e.currentTarget.style.background = '#E31B23'}
                >
                  НАПИСАТЬ В TELEGRAM
                </a>
                <a
                  href="tel:+79115076060"
                  className="px-10 py-4 font-bold tracking-widest text-sm border transition-all"
                  style={{ borderColor: '#F5F5F5', color: '#F5F5F5', letterSpacing: '0.1em', minHeight: '56px', display: 'inline-flex', alignItems: 'center' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(245,245,245,0.08)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  +7 911 507 6060
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}