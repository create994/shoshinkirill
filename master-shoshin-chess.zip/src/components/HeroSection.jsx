import { useState } from "react";

export default function HeroSection() {
  const [fideHover, setFideHover] = useState(false);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden" style={{ background: '#050505' }}>
      {/* Background chess pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 60px, rgba(227,27,35,0.3) 60px, rgba(227,27,35,0.3) 61px), repeating-linear-gradient(90deg, transparent, transparent 60px, rgba(227,27,35,0.3) 60px, rgba(227,27,35,0.3) 61px)`
      }} />

      {/* Red vertical line accent */}
      <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: 'linear-gradient(to bottom, transparent, #E31B23, transparent)' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full pt-24 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-0 items-center">
          {/* Left — text */}
          <div className="order-2 lg:order-1">
            <div className="mb-6 flex items-center gap-3">
              <div className="h-px flex-1 max-w-12" style={{ background: '#E31B23' }} />
              <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ПРЕМИАЛЬНЫЙ ШАХМАТНЫЙ ТРЕНЕР · ВЛЮБЛЕННЫЙ В СВОЁ ДЕЛО МАСТЕР</span>
            </div>

            <h1 className="font-black leading-none mb-2" style={{ fontSize: 'clamp(3.5rem, 10vw, 8rem)', letterSpacing: '-0.03em', color: '#F5F5F5' }}>
              КИРИЛЛ
            </h1>
            <h1 className="font-black leading-none mb-8" style={{ fontSize: 'clamp(3.5rem, 10vw, 8rem)', letterSpacing: '-0.03em', color: '#E31B23' }}>
              ШОШИН
            </h1>

            <p className="text-base md:text-lg mb-10 leading-relaxed max-w-lg" style={{ color: '#888' }}>
              <strong style={{ color: '#F5F5F5', fontWeight: 700 }}>FIDE Master</strong> с 16 лет. Игрок <strong style={{ color: '#F5F5F5', fontWeight: 700 }}>Топ-10 России</strong> в своем возрасте. Входит в <strong style={{ color: '#F5F5F5', fontWeight: 700 }}>0.01% лучших игроков планеты</strong> в онлайн <strong style={{ color: '#F5F5F5', fontWeight: 700 }}>по всем контролям.</strong>
              <br /><strong style={{ color: '#F5F5F5', fontWeight: 700 }}>85+</strong><span style={{ color: '#888' }}> учеников. </span><strong style={{ color: '#F5F5F5', fontWeight: 700 }}>6+</strong><span style={{ color: '#888' }}> лет преподавания.</span>
            </p>

            <div className="flex flex-wrap gap-4 mb-12">
              <a
                href="https://t.me/SHOSHIN_KIRILL"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 font-semibold tracking-widest text-sm transition-all"
                style={{ background: '#E31B23', color: '#fff', letterSpacing: '0.1em', minHeight: '56px', display: 'flex', alignItems: 'center' }}
                onMouseEnter={e => { e.currentTarget.style.background = '#c01419'; }}
                onMouseLeave={e => { e.currentTarget.style.background = '#E31B23'; }}
              >
                ЗАПИСАТЬСЯ В TELEGRAM
              </a>
              <a
                href="tel:+79115076060"
                className="px-8 py-4 font-semibold tracking-widest text-sm border transition-all"
                style={{ borderColor: '#F5F5F5', color: '#F5F5F5', letterSpacing: '0.1em', minHeight: '56px', display: 'flex', alignItems: 'center' }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(245,245,245,0.1)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
              >
                +7 911 507 6060
              </a>
            </div>


          </div>

          {/* Right — photo */}
          <div className="order-1 lg:order-2 relative flex justify-center lg:justify-end">
            <div className="relative">
              <div className="absolute inset-0 -m-2" style={{ background: 'linear-gradient(135deg, #E31B23 0%, transparent 60%)', opacity: 0.3, zIndex: 0 }} />
              <img
                src="https://media.base44.com/images/public/user_69ce39ac76ac3639b76873f2/780ec996a_SkyParkPNG.png"
                alt="Кирилл Шошин"
                className="relative z-10 object-cover"
                style={{ width: '340px', height: '420px', objectFit: 'cover', objectPosition: 'center top', filter: 'contrast(1.05)' }}
              />
              <div className="absolute -left-4 top-8 bottom-8 w-0.5 z-20" style={{ background: '#E31B23' }} />
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="mt-20 lg:mt-16 grid grid-cols-2 md:grid-cols-4 gap-0 border-t" style={{ borderColor: 'rgba(227,27,35,0.2)' }}>
          {[
            ['15+', 'лет в шахматах'],
            ['6+', 'лет преподавания'],
            ['85+', 'учеников'],
            ['0.01%', 'лучших на Lichess'],
          ].map(([num, label]) => (
            <div key={label} className="py-6 px-4 border-r last:border-r-0" style={{ borderColor: 'rgba(227,27,35,0.2)' }}>
              <div className="text-2xl md:text-3xl font-black mb-1" style={{ color: '#E31B23' }}>{num}</div>
              <div className="text-xs" style={{ color: '#888', letterSpacing: '0.1em' }}>{label.toUpperCase()}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}