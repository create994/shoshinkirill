import { useState } from "react";

export default function QASection() {
  const [open, setOpen] = useState(null);

  const qa = [
    {
      q: "В каком формате проходят занятия? Нужно ли что-то скачивать?",
      a: "Занятия проходят на платформе Яндекс Телемост — она работает в любом браузере без установки. Перед занятием я пришлю ссылку. Ничего лишнего.",
    },
    {
      q: "Останутся ли у меня материалы занятия после урока?",
      a: "Да. Все материалы сохраняются в удобном структурированном формате — с аннотациями и разбором. К ним можно вернуться в любой момент и освежить знания.",
    },
    {
      q: "Тренер завершил карьеру или ещё имеет профессиональные амбиции?",
      a: "Я продолжаю активно работать над собственным уровнем. Моя текущая цель — звание International Master (IM). Тренер, который сам растёт — передаёт живые знания, а не архивы.",
    },
    {
      q: "Можно ли заниматься на английском языке?",
      a: "Да, я свободно владею английским. Готов вести занятия полностью на английском — или интегрировать элементы языкового обучения в шахматный процесс. Удобно для иностранных учеников.",
    },
    {
      q: "Каков личный взгляд тренера на Игру Королей?",
      a: "Шахматы — это уникальная комбинация искусства, науки и спорта. Каждый шахматист способен развить свой неповторимый стиль подобно художнику. Без кропотливой работы над мельчайшими деталями в стиле учёного будет невозможно добиться по-настоящему великих результатов. Все лучшие шахматисты мира обладают фантастической физической формой, чтобы выдерживать партии по 6 и более часов.",
    },
  ];

  return (
    <section className="py-32" style={{ background: '#070707' }}>
      <div className="max-w-4xl mx-auto px-6 md:px-12">
        <div className="mb-16 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ВОПРОСЫ И ОТВЕТЫ</span>
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
          </div>
          <h2 className="font-black" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
            Остались вопросы?
          </h2>
        </div>

        <div className="space-y-0">
          {qa.map((item, i) => (
            <div key={i} style={{ borderTop: '1px solid rgba(227,27,35,0.15)', borderBottom: i === qa.length - 1 ? '1px solid rgba(227,27,35,0.15)' : 'none' }}>
              <button
                className="w-full text-left py-6 flex items-start justify-between gap-4 transition-colors"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span className="text-base font-semibold leading-relaxed pr-4" style={{ color: open === i ? '#F5F5F5' : '#aaa' }}>
                  <span className="font-black mr-3" style={{ color: '#E31B23' }}>
                    {String(i + 1).padStart(2, '0')}.
                  </span>
                  {item.q}
                </span>
                <span
                  className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-lg transition-transform duration-300"
                  style={{ color: '#E31B23', transform: open === i ? 'rotate(45deg)' : 'rotate(0deg)' }}
                >
                  +
                </span>
              </button>
              {open === i && (
                <div className="pb-6 pl-8 pr-8">
                  <p className="text-base leading-relaxed" style={{ color: '#888' }}>{item.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}