import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const NAV_ITEMS = [
  { label: 'Достижения', href: '#achievements' },
  { label: 'Наставник', href: '#mentor' },
  { label: 'Результаты', href: '#cases' },
  { label: 'Обо мне', href: '#about' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Инвестиция', href: '#pricing' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (href) => {
    setMobileOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav className={`fixed top-[2px] left-0 w-full z-40 transition-all duration-500 ${
      scrolled ? 'bg-obsidian/90 backdrop-blur-md border-b border-white/5' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between h-16">
        <button onClick={() => handleClick('#hero')} className="font-display text-xl text-ivory tracking-wider hover:text-crimson transition-colors">
          SHOSHIN
        </button>

        {/* Desktop */}
        <div className="hidden lg:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.href}
              onClick={() => handleClick(item.href)}
              className="text-sm text-steel hover:text-crimson transition-colors tracking-wide uppercase font-body"
            >
              {item.label}
            </button>
          ))}
          <a
            href="https://t.me/SHOSHIN_KIRILL"
            target="_blank"
            rel="noopener noreferrer"
            className="ml-4 px-5 py-2 bg-crimson text-ivory text-sm font-medium tracking-wider uppercase hover:bg-crimson/90 transition-colors"
          >
            Связаться
          </a>
        </div>

        {/* Mobile toggle */}
        <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden text-ivory">
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-obsidian/95 backdrop-blur-md border-t border-white/5">
          <div className="px-6 py-6 space-y-4">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.href}
                onClick={() => handleClick(item.href)}
                className="block text-sm text-steel hover:text-crimson transition-colors tracking-wide uppercase w-full text-left"
              >
                {item.label}
              </button>
            ))}
            <a
              href="https://t.me/SHOSHIN_KIRILL"
              target="_blank"
              rel="noopener noreferrer"
              className="block mt-4 px-5 py-3 bg-crimson text-ivory text-sm font-medium tracking-wider uppercase text-center hover:bg-crimson/90 transition-colors"
            >
              Связаться
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}