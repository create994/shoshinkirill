export default function AchievementsSection() {
  const achievements = [
    {
      label: "FIDE Master",
      sub: "с 16 лет",
      desc: "Получил звание FIDE Master в 2022 году — один из немногих шахматистов России, удостоенных этого звания в столь раннем возрасте.",
      link: "https://drive.google.com/file/d/1xvHLfPS6oqmOKl3kyqVTmO3pp4j9a4il/view?usp=drive_link",
      linkLabel: "Смотреть сертификат",
      img: "https://media.base44.com/images/public/user_69ce39ac76ac3639b76873f2/614af1e97_FIDEtitle.PNG",
    },
    {
      label: "Топ-10 России",
      sub: "многократно",
      desc: "Неоднократно входил в десятку сильнейших шахматистов России в своей возрастной категории. Стена наград — немое свидетельство стабильного превосходства.",
      link: "https://drive.google.com/file/d/1aezD9PjetG8KnILHPTnw8UwnBYaTDM-n/view?usp=drive_link",
      linkLabel: "Смотреть стену наград",
      img: "https://media.base44.com/images/public/user_69ce39ac76ac3639b76873f2/3d3c8cb3f_.jpg",
    },
    {
      label: "Чемпионат Европы",
      sub: "уровень IM",
      desc: "На мужском Чемпионате Европы продемонстрировал результат уровня Международного Мастера против элиты — действующих гроссмейстеров.",
      link: "https://drive.google.com/file/d/1IWiWKcFrwPAfM-bP_qdPEVARYxppS6gN/view?usp=drive_link",
      linkLabel: "Смотреть результат",
      img: "https://media.base44.com/images/public/69ce3a1749f1477335791fdd/8804ae6f7_EuropeanChessUnion.png",
    },
  ];

  return (
    <section id="achievements" className="py-32" style={{ background: '#050505' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ОФИЦИАЛЬНЫЕ ДОСТИЖЕНИЯ</span>
          </div>
          <h2 className="font-black" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
            Послужной список,<br />
            <span style={{ color: '#E31B23' }}>говорящий сам за себя</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {achievements.map((a, i) => (
            <div
              key={i}
              className="relative overflow-hidden group transition-all duration-300"
              style={{ background: '#0a0a0a', border: '1px solid rgba(227,27,35,0.15)' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(227,27,35,0.5)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(227,27,35,0.15)'}
            >
              {/* Image */}
              <div className="h-48 overflow-hidden relative">
                <img
                  src={a.img}
                  alt={a.label}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ filter: 'grayscale(0.2) contrast(1.05)' }}
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, #0a0a0a, transparent)' }} />
              </div>

              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-xl font-black" style={{ color: '#F5F5F5' }}>{a.label}</h3>
                    <p className="text-xs tracking-widest mt-0.5" style={{ color: '#E31B23', letterSpacing: '0.2em' }}>{a.sub.toUpperCase()}</p>
                  </div>
                  <span className="text-3xl font-black opacity-20" style={{ color: '#E31B23' }}>{String(i + 1).padStart(2, '0')}</span>
                </div>
                <p className="text-sm leading-relaxed mb-5" style={{ color: '#888' }}>{a.desc}</p>
                <a
                  href={a.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold tracking-widest inline-flex items-center gap-2 transition-colors"
                  style={{ color: '#E31B23', letterSpacing: '0.15em' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#ff4444'}
                  onMouseLeave={e => e.currentTarget.style.color = '#E31B23'}
                >
                  {a.linkLabel.toUpperCase()}
                  <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M7 17L17 7M17 7H7M17 7v10" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}