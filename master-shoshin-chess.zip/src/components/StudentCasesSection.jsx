export default function StudentCasesSection() {
  const cases = [
    { name: "Кирилл", age: 9, result: "43 → 4 место", detail: "Воронежская область", time: "3,5 мес.", color: "#E31B23" },
    { name: "Арина", age: 14, result: "3× Чемпионка СЗФО", detail: "В разных возрастных категориях", time: "2 года", color: "#E31B23" },
    { name: "Даниил", age: 17, result: "2 разряд → КМС", detail: "Кандидат в Мастера Спорта", time: "4,5 мес.", color: "#E31B23" },
    { name: "Егор", age: 9, result: "1 юн. разряд", detail: "Резкий рывок", time: "1 мес.", color: "#E31B23" },
    { name: "Амир", age: 27, result: "КМС", detail: "Психология + дебюты", time: "4,5 мес.", color: "#E31B23" },
    { name: "Иван", age: 35, result: "+1000 Elo", detail: "Lichess · 1 занятие/нед.", time: "1,5 года", color: "#E31B23" },
    { name: "Тим", age: 31, result: "+400 Rapid", detail: "Lichess · с перерывами", time: "8 мес.", color: "#E31B23" },
    { name: "Саша", age: null, result: "+200 Rapid", detail: "Призы на турнирах Москвы", time: "7 мес.", color: "#E31B23" },
    { name: "Kaiser Ansari", age: 20, result: "+700 Blitz", detail: "chess.com · дружеские занятия раз в месяц", time: "2 года", color: "#E31B23" },
    { name: "Алексей", age: 7, result: "+700 Rapid", detail: "Новичок → сильный любитель", time: "1 год", color: "#E31B23" },
    { name: "Александр", age: 25, result: "Победитель + КМС", detail: "Алгоритмы принятия решений · 2 занятия", time: "", color: "#E31B23" },
    { name: "Кирилл", age: 17, result: "КМС → IM норма", detail: "FIDE Master + норма IM · психология", time: "3 мес.", color: "#E31B23" },
  ];

  return (
    <section id="cases" className="py-32" style={{ background: '#070707' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="mb-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>РЕАЛЬНЫЕ РЕЗУЛЬТАТЫ</span>
          </div>
          <h2 className="font-black mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
            Прогресс,<br />
            <span style={{ color: '#E31B23' }}>за который говорят цифры</span>
          </h2>
          <p className="max-w-2xl text-base leading-relaxed mb-12" style={{ color: '#F5F5F5' }}>
            Индивидуальные занятия с 2020 года. Среди учеников — дети и взрослые, россияне и иностранцы. Способен найти индивидуальный и захватывающий подход к абсолютно любому. В таких условиях <strong style={{ color: '#E31B23' }}>результат гарантирован</strong>.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {cases.map((c, i) => (
            <div
              key={i}
              className="relative overflow-hidden group transition-all duration-300"
              style={{ background: '#0a0a0a', border: '1px solid rgba(227,27,35,0.12)', padding: '1.5rem' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#E31B23'; e.currentTarget.style.transform = 'translateY(-4px)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(227,27,35,0.12)'; e.currentTarget.style.transform = 'translateY(0)'; }}
            >
              <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: 'linear-gradient(to right, #E31B23, transparent)' }} />
              
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="font-black text-lg" style={{ color: '#F5F5F5' }}>{c.name}</p>
                  {c.age && <p className="text-xs" style={{ color: '#888' }}>{c.age} лет</p>}
                </div>
                {c.time && (
                  <span className="text-xs px-2 py-1" style={{ background: 'rgba(227,27,35,0.1)', color: '#E31B23', letterSpacing: '0.1em' }}>
                    {c.time}
                  </span>
                )}
              </div>

              <p className="text-2xl font-black mb-1" style={{ color: '#E31B23' }}>{c.result}</p>
              <p className="text-xs leading-relaxed" style={{ color: '#888' }}>{c.detail}</p>
            </div>
          ))}
        </div>

        {/* Reviews link */}
        <div className="mt-12 flex items-center gap-4">
          <div className="h-px flex-1" style={{ background: 'rgba(227,27,35,0.2)' }} />
          <a
            href="https://www.avito.ru/brands/50780bc3662f14f172f49050637bf3a4/all/predlozheniya_uslug?src=search_seller_info&iid=7951772649&sellerId=b4db6a7fd1f96d90bdf7488ec92269ed"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 text-sm font-semibold tracking-widest transition-all inline-flex items-center gap-2"
            style={{ border: '1px solid rgba(227,27,35,0.4)', color: '#E31B23', letterSpacing: '0.1em' }}
            onMouseEnter={e => e.currentTarget.style.background = 'rgba(227,27,35,0.1)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            ВСЕ ОТЗЫВЫ НА AVITO
            <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M7 17L17 7M17 7H7M17 7v10" />
            </svg>
          </a>
          <div className="h-px flex-1" style={{ background: 'rgba(227,27,35,0.2)' }} />
        </div>
      </div>
    </section>
  );
}