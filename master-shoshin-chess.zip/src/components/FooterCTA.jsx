export default function FooterCTA() {
  return (
    <footer className="bg-[#030303] border-t border-white/5 py-20 px-6 lg:px-16">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="font-playfair text-4xl lg:text-5xl text-ivory mb-4 leading-tight">
              Ваш следующий ход —<br />
              <em className="text-crimson">написать мне</em>
            </h2>
            <p className="text-steel text-base leading-relaxed max-w-md">
              Первый шаг к серьёзному прогрессу — договориться о пробном занятии. Без обязательств.
            </p>
          </div>
          <div className="flex flex-col gap-4">
            <a
              href="https://t.me/SHOSHIN_KIRILL"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-crimson text-ivory px-8 py-5 text-sm font-medium tracking-widest uppercase hover:bg-red-700 transition-all duration-300 min-h-[56px] group"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248l-1.97 9.289c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.932z"/>
              </svg>
              Написать в Telegram
            </a>
            <a
              href="tel:+79115076060"
              className="flex items-center gap-4 border border-ivory/20 text-ivory/70 px-8 py-5 text-sm font-medium tracking-widest uppercase hover:border-ivory/50 hover:text-ivory transition-all duration-300 min-h-[56px]"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 8.81 19.79 19.79 0 01.0 0.18 2 2 0 012 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
              </svg>
              Позвонить: +7 911 507 6060
            </a>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-[1px] w-8 bg-crimson" />
            <span className="font-playfair text-xl text-ivory">SHOSHIN</span>
          </div>
          <div className="text-steel text-sm">
            FM Кирилл Шошин · FIDE ID: 34167061 · @Kirill_Shoshin
          </div>
        </div>
      </div>
    </footer>
  );
}