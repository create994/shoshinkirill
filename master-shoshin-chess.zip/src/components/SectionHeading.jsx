export default function SectionHeading({ label, title, align = 'left' }) {
  return (
    <div className={`mb-16 ${align === 'center' ? 'text-center' : ''}`}>
      <div className={`flex items-center gap-3 mb-4 ${align === 'center' ? 'justify-center' : ''}`}>
        <div className="w-8 h-px bg-crimson" />
        <span className="text-crimson text-xs tracking-[0.4em] uppercase font-body">{label}</span>
        <div className="w-8 h-px bg-crimson" />
      </div>
      <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-ivory leading-tight">
        {title}
      </h2>
    </div>
  );
}