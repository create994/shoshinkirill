import { useState, useEffect, useRef } from "react";

function CountUp({ target, duration = 2000 }) {
  const [value, setValue] = useState(0);
  const ref = useRef(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const start = Date.now();
          const tick = () => {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            setValue(+(target * progress).toFixed(1));
            if (progress < 1) requestAnimationFrame(tick);
            else setValue(target);
          };
          requestAnimationFrame(tick);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);

  return <span ref={ref}>{value.toFixed(1)}</span>;
}

export default function LichessSection() {
  const cards = [
    { type: "ПУЛЯ", rating: 3002, link: "https://lichess.org/@/Kirill_Shoshin/perf/bullet", icon: "⚡", desc: "Молниеносные решения. Абсолютная точность под предельным давлением времени." },
    { type: "БЛИЦ", rating: 2636, link: "https://lichess.org/@/Kirill_Shoshin/perf/blitz", icon: "🔥", desc: "Тактическая острота в формате, где каждая секунда — это стратегическое решение." },
    { type: "РАПИД", rating: 2402, link: "https://lichess.org/@/Kirill_Shoshin/perf/rapid", icon: "♞", desc: "Глубокое позиционное понимание. Здесь рождаются шедевры шахматной мысли." },
  ];

  return (
    <section id="lichess" className="py-32" style={{ background: '#070707' }}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-12" style={{ background: '#E31B23' }} />
            <span className="text-xs tracking-widest" style={{ color: '#E31B23', letterSpacing: '0.3em' }}>ОНЛАЙН-РЕЙТИНГ</span>
          </div>
          <h2 className="font-black mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)', color: '#F5F5F5', letterSpacing: '-0.02em' }}>
            0.01% лучших в мире<br />
            <span style={{ color: '#E31B23' }}>во всех форматах</span>
          </h2>
          <p className="max-w-2xl text-base leading-relaxed" style={{ color: '#888' }}>
            Lichess — одна из крупнейших шахматных платформ мира с десятками миллионов игроков. 
            Входить в 0.01% лучших одновременно по Пуле, Блицу и Рапиду — достижение, подтверждающее высший уровень компетентности.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {cards.map((c, i) => (
            <div
              key={i}
              className="relative overflow-hidden group"
              style={{ background: '#0a0a0a', border: '1px solid rgba(227,27,35,0.15)', padding: '2rem' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#E31B23'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(227,27,35,0.15)'}
            >
              <div className="absolute top-4 right-4 text-4xl opacity-20">{c.icon}</div>
              <p className="text-xs tracking-widest mb-4 font-bold" style={{ color: '#E31B23', letterSpacing: '0.25em' }}>{c.type}</p>
              
              <div className="mb-2">
                <span className="font-black" style={{ fontSize: '4rem', color: '#F5F5F5', lineHeight: 1 }}>
                  {c.rating}
                </span>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <div className="h-px flex-1" style={{ background: 'rgba(227,27,35,0.3)' }} />
                <span className="text-xs font-bold tracking-widest" style={{ color: '#E31B23' }}>ТОП 0.01% МИРА</span>
              </div>

              <p className="text-xs leading-relaxed mb-6" style={{ color: '#888' }}>{c.desc}</p>

              <a
                href={c.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold tracking-widest inline-flex items-center gap-2"
                style={{ color: '#E31B23', letterSpacing: '0.15em' }}
              >
                ПОДРОБНЕЕ
                <svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="M7 17L17 7M17 7H7M17 7v10" />
                </svg>
              </a>
            </div>
          ))}
        </div>

        {/* Lichess screenshot */}
        <div className="relative overflow-hidden" style={{ border: '1px solid rgba(227,27,35,0.2)' }}>
          <img
            src="https://media.base44.com/images/public/user_69ce39ac76ac3639b76873f2/4c0660dda_Lichessperfomance.png"
            alt="Lichess Performance"
            className="w-full"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(5,5,5,0.3), transparent, rgba(5,5,5,0.3))' }} />
        </div>
      </div>
    </section>
  );
}